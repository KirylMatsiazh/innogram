import { IsString, IsOptional, IsBoolean, MaxLength } from 'class-validator';

export class UpdateProfileDto {
    @IsString()
    @MaxLength(100)
    @IsOptional()
    displayName?: string;

    @IsString()
    @IsOptional()
    bio?: string;

    @IsString()
    @MaxLength(500)
    @IsOptional()
    avatarUrl?: string;

    @IsBoolean()
    @IsOptional()
    isPublic?: boolean;
}