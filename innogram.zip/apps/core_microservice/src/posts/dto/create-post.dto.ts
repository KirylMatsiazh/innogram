import { IsString, IsNotEmpty, IsUUID, IsOptional, IsBoolean } from 'class-validator';

export class CreatePostDto {
    @IsString()
    @IsNotEmpty()
    content: string;

    @IsUUID('4')
    @IsNotEmpty()
    profileId: string;

    @IsUUID('4')
    @IsNotEmpty()
    createdById: string;

    @IsBoolean()
    @IsOptional()
    isArchived?: boolean;
}