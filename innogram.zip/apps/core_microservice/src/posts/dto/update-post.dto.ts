import { IsString, IsOptional, IsBoolean } from 'class-validator';

export class UpdatePostDto {
    @IsString()
    @IsOptional()
    content?: string;

    @IsBoolean()
    @IsOptional()
    isArchived?: boolean;
}