import { Controller, Get, Post, Delete, Body, Param } from '@nestjs/common';
import { CommentsService } from './comments.service.js';
import { Comment } from '../database/entities/comment.entity.js';
import { CreateCommentDto } from './dto/create-comment.dto.js';

@Controller('comments')
export class CommentsController {
    constructor(private readonly commentsService: CommentsService) {}

    @Post()
    createComment(@Body() commentData: CreateCommentDto): Promise<Comment> {
        return this.commentsService.createComment(commentData);
    }

    @Get('post/:postId')
    findCommentsByPost(@Param('postId') postId: string): Promise<Comment[]> {
        return this.commentsService.findCommentsByPost(postId);
    }

    @Get(':id')
    findCommentById(@Param('id') id: string): Promise<Comment> {
        return this.commentsService.findCommentById(id);
    }

    @Delete(':id')
    deleteComment(@Param('id') id: string): Promise<{ deleted: boolean }> {
        return this.commentsService.deleteComment(id);
    }
}