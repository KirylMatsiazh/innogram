import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Chat } from '../database/entities/chat.entity.js';
import { Message } from '../database/entities/message.entity.js';
import { CreateChatDto } from './dto/create-chat.dto.js';
import { CreateMessageDto } from './dto/create-message.dto.js';

@Injectable()
export class ChatsService {
    constructor(
        @InjectRepository(Chat)
        private readonly chatRepository: Repository<Chat>,

        @InjectRepository(Message)
        private readonly messageRepository: Repository<Message>,
    ) {}

    // CHATS
    async createChat(chatData: CreateChatDto): Promise<Chat> {
        const chat = this.chatRepository.create(chatData);
        return this.chatRepository.save(chat);
    }

    async findChatById(id: string): Promise<Chat> {
        const chat = await this.chatRepository.findOneBy({ id });
        if (!chat) {
            throw new NotFoundException(`Chat with ID ${id} not found`);
        }
        return chat;
    }

    // MESSAGES
    async createMessage(chatId: string, messageData: CreateMessageDto): Promise<Message> {
        await this.findChatById(chatId); // Existence check

        const message = this.messageRepository.create({
            ...messageData,
            chatId: chatId,
        });
        return this.messageRepository.save(message);
    }

    async findMessagesByChat(chatId: string): Promise<Message[]> {
        await this.findChatById(chatId); // Existence check

        return this.messageRepository.find({
            where: { chatId: chatId },
            order: { createdAt: 'ASC' },
        });
    }
}