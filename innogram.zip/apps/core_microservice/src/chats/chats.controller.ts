import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { ChatsService } from './chats.service.js';
import { Chat } from '../database/entities/chat.entity.js';
import { Message } from '../database/entities/message.entity.js';
import { CreateChatDto } from './dto/create-chat.dto.js';
import { CreateMessageDto } from './dto/create-message.dto.js';

@Controller('chats')
export class ChatsController {
    constructor(private readonly chatsService: ChatsService) {}

    @Post()
    createChat(@Body() chatData: CreateChatDto): Promise<Chat> {
        return this.chatsService.createChat(chatData);
    }

    @Get(':id')
    findChatById(@Param('id') id: string): Promise<Chat> {
        return this.chatsService.findChatById(id);
    }

    @Post(':id/messages')
    createMessage(
        @Param('id') chatId: string,
        @Body() messageData: CreateMessageDto,
    ): Promise<Message> {
        return this.chatsService.createMessage(chatId, messageData);
    }

    @Get(':id/messages')
    findMessagesByChat(@Param('id') chatId: string): Promise<Message[]> {
        return this.chatsService.findMessagesByChat(chatId);
    }
}
