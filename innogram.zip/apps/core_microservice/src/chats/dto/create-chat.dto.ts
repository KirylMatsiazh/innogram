import { IsString, IsNotEmpty, IsOptional, MaxLength, IsIn, IsUUID } from 'class-validator';

export class CreateChatDto {
    @IsString()
    @MaxLength(100)
    @IsNotEmpty()
    name: string;

    @IsString()
    @IsOptional()
    description?: string;

    @IsString()
    @IsIn(['private', 'group'])
    @IsOptional()
    type?: string;

    @IsUUID('4')
    @IsNotEmpty()
    createdById: string;
}