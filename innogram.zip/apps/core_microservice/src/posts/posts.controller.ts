import { Controller, Get, Post, Patch, Delete, Body, Param } from '@nestjs/common';
import { PostsService } from './posts.service.js';
import { Post as PostEntity } from '../database/entities/post.entity.js';
import { CreatePostDto } from './dto/create-post.dto.js';
import { UpdatePostDto } from './dto/update-post.dto.js';

@Controller('posts')
export class PostsController {
    constructor(private readonly postsService: PostsService) {}

    @Post()
    createPost(@Body() postData: CreatePostDto): Promise<PostEntity> {
        return this.postsService.createPost(postData);
    }

    @Get()
    findAllPosts(): Promise<PostEntity[]> {
        return this.postsService.findAllPosts();
    }

    @Get(':id')
    findPostById(@Param('id') id: string): Promise<PostEntity> {
        return this.postsService.findPostById(id);
    }

    @Patch(':id')
    updatePost(
        @Param('id') id: string,
        @Body() postData: UpdatePostDto,
    ): Promise<PostEntity> {
        return this.postsService.updatePost(id, postData);
    }

    @Delete(':id')
    deletePost(@Param('id') id: string): Promise<{ deleted: boolean }> {
        return this.postsService.deletePost(id);
    }
}