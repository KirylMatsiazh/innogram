import { IsString, IsOptional, IsBoolean } from 'class-validator';

export class CreateUserDto {
    @IsString()
    @IsOptional()
    role?: string;

    @IsBoolean()
    @IsOptional()
    disabled?: boolean;
}