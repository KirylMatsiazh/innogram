import { Controller, Get, Post, Body, Param, Patch } from '@nestjs/common';
import { UsersService } from './users.service.js';
import { User } from '../database/entities/user.entity.js';
import { Profile } from '../database/entities/profile.entity.js';
import { CreateUserDto } from './dto/create-user.dto.js';
import { UpdateProfileDto } from './dto/update-profile.dto.js';

// ENTITIES OWNED: 
// User(POST /users; GET /users/:id),
// Account,
// Profile(GET /users/:id/profile; PATCH /users/:id/profile),
// ProfileFollow
@Controller('users')
export class UsersController {
    constructor(
        private readonly usersService: UsersService
    ) { }

    @Post()
    createUser(@Body() userData: CreateUserDto): Promise<User> {
        return this.usersService.createUser(userData);
    }

    @Get(':id')
    findUser(@Param('id') id: string): Promise<User> {
        return this.usersService.findUser(id);
    }

    @Get(':id/profile')
    findProfile(@Param('id') id: string): Promise<Profile> {
        return this.usersService.findProfile(id);
    }

    @Patch(':id/profile')
    updateProfile(@Param('id') id: string, @Body() profileData: UpdateProfileDto): Promise<Profile> {
        return this.usersService.updateProfile(id, profileData);
    }
}