import { IsString, IsNotEmpty, IsUUID } from 'class-validator';

export class CreateCommentDto {
    @IsString()
    @IsNotEmpty()
    content: string;

    @IsUUID('4')
    @IsNotEmpty()
    postId: string;

    @IsUUID('4')
    @IsNotEmpty()
    profileId: string;

    @IsUUID('4')
    @IsNotEmpty()
    createdById: string;
}