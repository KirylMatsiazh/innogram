import { IsString, IsNotEmpty, IsUUID } from 'class-validator';

export class CreateMessageDto {
    @IsString()
    @IsNotEmpty()
    content: string;

    @IsUUID('4')
    @IsNotEmpty()
    profileId: string;

    @IsUUID('4')
    @IsNotEmpty()
    createdBy: string;
}